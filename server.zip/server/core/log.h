#pragma once
// 日志级别控制（轻量、单头文件、无依赖）
//   g_packet_log = true   输出全部日志（含每个收发数据包的"次要日志"，用于诊断）
//   g_packet_log = false  只输出"重点日志"（启动/错误/握手/密钥等关键事件）
//                         公网服务器建议开启 --quiet 关闭次要日志，减少刷屏
// 通过 vpn_server 的 --quiet 参数切换
inline bool g_packet_log = true;  // C++17 inline 变量：整个程序共享一份
